import cdk = require('@aws-cdk/cdk');
export declare class CdkWorkshopStack extends cdk.Stack {
    constructor(scope: cdk.App, id: string, props?: cdk.StackProps);
}
